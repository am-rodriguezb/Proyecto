/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import bdMOVIE.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Movie;

/**
 *
 * @author Y409-PCXX
 */
public class ControlarMovies {
    
    public void agregar(Movie temp) {
        try {
            Conexion conexion1 = new Conexion();
            Connection cnx = conexion1.obtenerConexion();
            
            String query = "INSERT INTO movie(tituloMOVIE, directorMOVIE, añoMOVIE, duracionMOVIE, generoMOVIE) VALUES (?,?,?,?,?)";
            PreparedStatement stmt = cnx.prepareStatement(query);
            
            stmt.setString(1, temp.getTituloMOVIE());
            stmt.setString(2, temp.getDirectorMOVIE());
            stmt.setInt(3, temp.getAñoMOVIE());
            stmt.setInt(4, temp.getDuracionMOVIE());
            stmt.setString(5, temp.getGeneroMovie());

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
        } catch (SQLException e) {
            System.out.println("Error SQL al agregar pelicula" + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error al agregar pelicula" + e.getMessage());
        }
    }
    
    public void agregarMovie(){
        try {
            
        }catch (Exception e){
            System.out.println("Error al agregar un pelicula "+ e.getMessage());
        }
    }
            
}
