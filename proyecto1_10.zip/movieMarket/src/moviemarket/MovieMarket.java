/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package moviemarket;

import bdMOVIE.Conexion;
import controlador.ControlarMovies;
import modelo.Movie;
import vista.Login;

/**
 *
 * @author Y409-PCXX
 */
public class MovieMarket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Conexion conect = new Conexion();
        
        Login objeto1 = new Login();
        objeto1.setVisible(true);
    }
    
}
