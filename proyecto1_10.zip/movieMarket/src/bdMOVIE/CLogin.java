/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bdMOVIE;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Y409-PCXX
 */
public class CLogin {

    public void validarUser(JTextField user, JPasswordField pass) {
        try {
            PreparedStatement ps = null;
            ResultSet rs = null;
            Conexion conn = new Conexion();
            Connection conexion = conn.obtenerConexion();
            String sql = "SELECT * FROM moviesbd.usuario WHERE ingresoUsuario = (?) and ingresoContraseña = (?);";
            ps = conexion.prepareStatement(sql);
            String contra = String.valueOf(pass.getPassword());
            
            ps.setString(1, user.getText());
            ps.setString(2, contra);
            rs = ps.executeQuery();
            
            if(rs.next()){
                JOptionPane.showMessageDialog(null, "El usuario es correcto");
                vista.menu menu1=new vista.menu();
                
                menu1.setVisible(true);

                
            }else{
                JOptionPane.showMessageDialog(null, "El usuario es incorrecto o la contrseña es incorrecta.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR "+e.toString());
        }
    }
}
