/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package moviemarket;

import bdMOVIE.Conexion;
import controlador.ControlarMovies;
import modelo.Movie;

/**
 *
 * @author Y409-PCXX
 */
public class MovieMarket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Conexion conect = new Conexion();
        conect.obtenerConexion();
        
        Movie test=new Movie();
        Movie movie1 = new Movie("007 no puede la arma","Arnol Gonzales",2005,95,"Comedia");
        ControlarMovies metodo= new ControlarMovies();
        
        metodo.agregar(movie1);
        
    }
    
}
