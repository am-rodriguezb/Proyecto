/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import bdMOVIE.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Movie;

/**
 *
 * @author Y409-PCXX
 */
public class ControlarMovies {
    
    public void agregar(Movie temp) {
        try {
            Conexion conexion1 = new Conexion();
            Connection cnx = conexion1.obtenerConexion();
            
            String query = "INSERT INTO movie(tituloMOVIE, directorMOVIE, añoMOVIE, duracionMOVIE, generoMOVIE) VALUES (?,?,?,?,?)";
            PreparedStatement stmt = cnx.prepareStatement(query);
            
            stmt.setString(1, temp.getTituloMOVIE());
            stmt.setString(2, temp.getDirectorMOVIE());
            stmt.setInt(3, temp.getAñoMOVIE());
            stmt.setInt(4, temp.getDuracionMOVIE());
            stmt.setString(5, temp.getGeneroMovie());

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
        } catch (SQLException e) {
            System.out.println("Error SQL al agregar pelicula" + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error al agregar pelicula" + e.getMessage());
        }
    }
    
    public void agregarMovie(){
        try {
            
        }catch (Exception e){
            System.out.println("Error al agregar un pelicula "+ e.getMessage());
        }
    }
    public boolean eliminar(int idMOVIE) {
        try {
            Conexion conexion1 = new Conexion();
            Connection cnx = conexion1.obtenerConexion();

            String query = "DELETE FROM movie WHERE idMOVIE=?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, idMOVIE);

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Error SQL al eliminar pelicula " + e.getMessage());
            return false;
        } catch (Exception e) {
            System.out.println("Error al eliminar pelicula " + e.getMessage());
            return false;
        }
    }
        public void mostrar(JTable tabla) {
        

        try {
            DefaultTableModel modelo = new DefaultTableModel();
            tabla.setModel(modelo);
            PreparedStatement ps = null;
            ResultSet rs = null;
            Conexion conn = new Conexion();
            Connection con = conn.obtenerConexion();
            String sql = "SELECT idMOVIE,tituloMOVIE,directorMOVIE,añoMOVIE,duracionMOVIE,generoMOVIE FROM moviedb.movie ";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            java.sql.ResultSetMetaData rsMd = rs.getMetaData();
            int cantidadColumnas = rsMd.getColumnCount();

            modelo.addColumn("idMOVIE");
            modelo.addColumn("tituloMOVIE");
            modelo.addColumn("directorMOVIE");
            modelo.addColumn("añoMOVIE");
            modelo.addColumn("duracionMOVIE");
            modelo.addColumn("generoMOVIE");

            while (rs.next()) {
                Object[] filas = new Object[cantidadColumnas];
                for (int i = 0; i < cantidadColumnas; i++) {
                    filas[i] = rs.getObject(i + 1);

                }
                modelo.addRow(filas);
            }

        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos: " + ex.getMessage());

        }
    }

            
}
