/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Y409-PCXX
 */
public class movie {
    private int idMOVIE;
    private String tituloMOVIE, directorMOVIE;
    private int añoMOVIE, duracionMOVIE;
    private String generoMovie;

    public movie() {
    }

    public movie(int idMOVIE, String tituloMOVIE, String directorMOVIE, int añoMOVIE, int duracionMOVIE, String generoMovie) {
        this.idMOVIE = idMOVIE;
        this.tituloMOVIE = tituloMOVIE;
        this.directorMOVIE = directorMOVIE;
        this.añoMOVIE = añoMOVIE;
        this.duracionMOVIE = duracionMOVIE;
        this.generoMovie = generoMovie;
    }

    public int getIdMOVIE() {
        return idMOVIE;
    }

    public void setIdMOVIE(int idMOVIE) {
        this.idMOVIE = idMOVIE;
    }

    public String getTituloMOVIE() {
        return tituloMOVIE;
    }

    public void setTituloMOVIE(String tituloMOVIE) {
        this.tituloMOVIE = tituloMOVIE;
    }

    public String getDirectorMOVIE() {
        return directorMOVIE;
    }

    public void setDirectorMOVIE(String directorMOVIE) {
        this.directorMOVIE = directorMOVIE;
    }

    public int getAñoMOVIE() {
        return añoMOVIE;
    }

    public void setAñoMOVIE(int añoMOVIE) {
        this.añoMOVIE = añoMOVIE;
    }

    public int getDuracionMOVIE() {
        return duracionMOVIE;
    }

    public void setDuracionMOVIE(int duracionMOVIE) {
        this.duracionMOVIE = duracionMOVIE;
    }

    public String getGeneroMovie() {
        return generoMovie;
    }

    public void setGeneroMovie(String generoMovie) {
        this.generoMovie = generoMovie;
    }

    @Override
    public String toString() {
        return "movie{" + "idMOVIE=" + idMOVIE + ", tituloMOVIE=" + tituloMOVIE + ", directorMOVIE=" + directorMOVIE + ", a\u00f1oMOVIE=" + añoMOVIE + ", duracionMOVIE=" + duracionMOVIE + ", generoMovie=" + generoMovie + '}';
    }
    
}
