/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bdMOVIE;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Y409-PCXX
 */
public class Conexion {

    public Conexion() {
    }
    
    
    public Connection obtenerConexion() {
        Connection connection = null;
        try {
            //Conexion casa
            //connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "123456");
            System.out.println("Conexión exitosa");
        } catch (SQLException e) {
            System.out.println("Error de conexión" + e.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return connection;
    }
}
